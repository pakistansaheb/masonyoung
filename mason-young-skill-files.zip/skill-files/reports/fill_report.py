"""Fill a Mason Young appraisal letter by editing the firm's real template in place.

Usage: python3 fill_report.py template.docx spec.json out.docx

spec = {
  "replace": [["old paragraph text (exact, stripped)", "new text"], ...],
      new text may mark money with [[...]] -> yellow highlight, ^^th^^ -> superscript
  "starts_with": [["start of old paragraph", "new text"], ...],   # for long paragraphs
  "delete_starts_with": ["start of paragraph to delete", ...],
  "table": {"Marketing Board": "[[£250]]", ...},                 # cost column by row label
  "footer_replace": [["old", "new"], ...]                           # plain text swaps in footers
}
Paragraph pPr and the first run's rPr are kept, so fonts/spacing never change.
Any existing yellow highlight from the template is removed from edited text;
only [[money]] gets highlighted.
"""
import copy, json, re, sys, zipfile
from lxml import etree

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
q = lambda t: '{%s}%s' % (W, t)
XS = '{http://www.w3.org/XML/1998/namespace}space'


def ptext(p):
    return ''.join(t.text or '' for t in p.iter(q('t')) if next(t.iterancestors(q('p'))) is p)


def segments(text):
    """'a [[£1]] b ^^th^^' -> [('a ', ''), ('£1', 'hl'), (' b ', ''), ('th', 'sup')]"""
    out = []
    for part in re.split(r'(\[\[.*?\]\]|\^\^.*?\^\^)', text):
        if not part:
            continue
        if part.startswith('[['):
            out.append((part[2:-2], 'hl'))
        elif part.startswith('^^'):
            out.append((part[2:-2], 'sup'))
        else:
            out.append((part, ''))
    return out


def set_text(p, text):
    runs = [r for r in p.findall(q('r')) if r.find(q('t')) is not None]
    if not runs:
        raise ValueError('no text run in %r' % ptext(p))
    proto = runs[0]
    for r in runs:
        p.remove(r) if r is not proto else None
    anchor = proto
    for k, (s, kind) in enumerate(segments(text)):
        r = copy.deepcopy(proto)
        for t in r.findall(q('t'))[1:]:
            r.remove(t)
        rpr = r.find(q('rPr'))
        if rpr is None:
            rpr = etree.SubElement(r, q('rPr')); r.remove(rpr); r.insert(0, rpr)
        for tag in ('highlight', 'vertAlign'):
            for el in rpr.findall(q(tag)):
                rpr.remove(el)
        if kind == 'hl':
            etree.SubElement(rpr, q('highlight')).set(q('val'), 'yellow')
        if kind == 'sup':
            etree.SubElement(rpr, q('vertAlign')).set(q('val'), 'superscript')
        t = r.find(q('t')); t.text = s; t.set(XS, 'preserve')
        anchor.addnext(r); anchor = r
    p.remove(proto)


def main(src, spec_path, out):
    spec = json.load(open(spec_path))
    zin = zipfile.ZipFile(src)
    files = {n: zin.read(n) for n in zin.namelist()}
    root = etree.fromstring(files['word/document.xml'])
    paras = list(root.iter(q('p')))

    for old, new in spec.get('replace', []):
        hits = [p for p in paras if ptext(p).strip() == old.strip()]
        if not hits:
            raise ValueError('not found: %r' % old)
        for p in hits:
            set_text(p, new)
    for start, new in spec.get('starts_with', []):
        hits = [p for p in paras if ptext(p).strip().startswith(start)]
        if not hits:
            raise ValueError('not found: %r' % start)
        for p in hits:
            set_text(p, new)
    for start in spec.get('delete_starts_with', []):
        for p in [p for p in paras if ptext(p).strip().startswith(start)]:
            nxt = p.getnext()
            p.getparent().remove(p)
            # drop the blank spacer that followed it, so spacing stays even
            if nxt is not None and nxt.tag == q('p') and not ptext(nxt).strip():
                nxt.getparent().remove(nxt)
    # add a heading (cloned from an existing one, with its blank spacer) before a paragraph
    for src_heading, new_heading, before_start in spec.get('insert_heading_before', []):
        paras = list(root.iter(q('p')))
        src = [p for p in paras if ptext(p).strip() == src_heading][0]
        target = [p for p in paras if ptext(p).strip().startswith(before_start)][0]
        h = copy.deepcopy(src); set_text(h, new_heading)
        sp = src.getnext()
        target.addprevious(h)
        if sp is not None and sp.tag == q('p') and not ptext(sp).strip():
            target.addprevious(copy.deepcopy(sp))
    paras = list(root.iter(q('p')))
    for start in spec.get('delete_empty_before', []):
        for p in [p for p in paras if ptext(p).strip().startswith(start)]:
            prev = p.getprevious()
            if prev is not None and prev.tag == q('p') and not ''.join(t.text or '' for t in prev.iter(q('t'))).strip():
                prev.getparent().remove(prev)
    for start in spec.get('page_break_before', []):
        for p in [p for p in paras if ptext(p).strip().startswith(start)]:
            ppr = p.find(q('pPr'))
            if ppr is None:
                ppr = etree.Element(q('pPr')); p.insert(0, ppr)
            if ppr.find(q('pageBreakBefore')) is None:
                el = etree.Element(q('pageBreakBefore'))
                # schema order: pStyle, keepNext, keepLines, pageBreakBefore ...
                after = [c for c in ppr if c.tag in (q('pStyle'), q('keepNext'), q('keepLines'))]
                (after[-1].addnext(el) if after else ppr.insert(0, el))
    for label, val in spec.get('table', {}).items():
        for tr in root.iter(q('tr')):
            cells = tr.findall(q('tc'))
            if cells and ''.join(t.text or '' for t in cells[0].iter(q('t'))).strip() == label:
                set_text(cells[-1].find('.//' + q('p')), val)

    # .doc -> .docx conversion leaves some runs with no font, falling back to
    # LibreOffice's 'Liberation Serif' default: give them the letter's Arial 10pt
    for r in root.iter(q('r')):
        if r.find(q('t')) is not None and (r.find(q('rPr')) is None or r.find(q('rPr') + '/' + q('rFonts')) is None):
            rpr = r.find(q('rPr'))
            if rpr is None:
                rpr = etree.Element(q('rPr')); r.insert(0, rpr)
            f = etree.Element(q('rFonts'))
            for a in ('ascii', 'hAnsi', 'cs'):
                f.set(q(a), 'Arial')
            rpr.insert(0, f)
            if rpr.find(q('sz')) is None:
                etree.SubElement(rpr, q('sz')).set(q('val'), '20'); etree.SubElement(rpr, q('szCs')).set(q('val'), '20')
    for name in ('word/styles.xml', 'word/fontTable.xml'):
        if name in files:
            files[name] = files[name].replace(b'Liberation Serif', b'Arial').replace(b'Liberation Sans', b'Arial')
    files['word/document.xml'] = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
    # use one footer everywhere (e.g. the JQ first-page footer on every page)
    fc = spec.get('footer_copy')
    if fc:
        files['word/' + fc['to']] = files['word/' + fc['from']]
        files['word/_rels/%s.rels' % fc['to']] = files['word/_rels/%s.rels' % fc['from']]
    for name in [n for n in files if re.match(r'word/footer\d+\.xml', n)]:
        x = files[name].decode('utf-8')
        for old, new in spec.get('footer_replace', []):
            # templates mix normal and non-breaking spaces; match any run of them
            pat = r'[\s\xa0]+'.join(re.escape(w) for w in old.split())
            x = re.sub(pat, lambda m: new, x)
        files[name] = x.encode('utf-8')
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for n in zin.namelist():
            z.writestr(zin.getinfo(n), files[n])
    print('saved', out)


if __name__ == '__main__':
    main(*sys.argv[1:4])
