"""Fill a Mason Young brochure by editing a FINISHED exemplar .docx in place.

Every paragraph keeps its own pPr and the rPr of its first text run, so fonts,
sizes, spacing, text boxes, lines and photo frames stay byte-identical to the
exemplar. Only words and photo pixels change.

Usage: python3 fill_brochure.py exemplar.docx spec.json out.docx

spec = {
  "subtitle": "GROUND FLOOR INDUSTRIAL",
  "address": ["UNIT 7, BICKFORD ROAD, WITTON", "BIRMINGHAM, B6 7EE"],   # cover lines
  "sqft_line": "2,280 SQ FT (212 SQ M)",
  "bullets": ["SELF-CONTAINED", "PARKING TO FRONT", "VARIETY OF USES", "FLEXIBLE TERMS"],
  "sections": {"LOCATION": ["para", ...], "DESCRIPTION": [...], "PLANNING": [...], ...},
  "accommodation": [["Ground Floor", "2,280", "212"], ...],
  "total": ["2,280", "212"],
  "photos": {"hero": "a.jpg", "gallery": ["b.jpg", "c.jpg", "d.jpg"]}
}
Anything left out of the spec stays exactly as the exemplar has it.
"""
import copy, io, json, re, sys, zipfile
from lxml import etree
from PIL import Image, ImageOps

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
V = 'urn:schemas-microsoft-com:vml'
q = lambda t: '{%s}%s' % (W, t)

HEADING = re.compile(r'^\s*([A-Z][A-Z /&]*?[A-Z])\s*\.{3,}')


def ptext(p):
    # only this paragraph's own words, never text inside nested text boxes
    return ''.join(t.text or '' for t in p.iter(q('t'))
                   if next(t.iterancestors(q('p'))) is p)


def alltext(el):
    return ''.join(t.text or '' for t in el.iter(q('t')))


def set_text(p, text):
    """Replace a paragraph's words, keeping pPr and the first text run's rPr."""
    runs = [r for r in p.findall(q('r')) if r.find(q('t')) is not None]
    if not runs:
        raise ValueError('paragraph has no text run: %r' % ptext(p))
    first = runs[0]
    for r in runs[1:]:
        p.remove(r)
    for t in first.findall(q('t'))[1:]:
        first.remove(t)
    t = first.find(q('t'))
    t.text = text
    t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')


def heading_of(p):
    m = HEADING.match(ptext(p))
    return m.group(1).strip() if m else None


def fill_sections(root, sections):
    """Each heading appears once per copy (DrawingML + VML fallback); do all."""
    for container in {p.getparent() for p in root.iter(q('p')) if heading_of(p)}:
        kids = list(container)
        for i, p in enumerate(kids):
            name = heading_of(p) if p.tag == q('p') else None
            if not name or name not in sections:
                continue
            # body = paragraphs up to the next heading (tables excluded)
            body = []
            for n in kids[i + 1:]:
                if n.tag == q('p') and heading_of(n):
                    break
                if n.tag == q('p'):
                    body.append(n)
            textp = [b for b in body if ptext(b).strip()]
            spacers = [b for b in body if not ptext(b).strip()]
            new = [s for s in sections[name] if s.strip()]
            if not textp:
                continue
            # reuse existing paragraphs; clone the last (with a spacer) for extras
            for j, s in enumerate(new):
                if j < len(textp):
                    set_text(textp[j], s)
                else:
                    anchor = textp[-1]
                    sp = copy.deepcopy(spacers[0]) if spacers else None
                    np_ = copy.deepcopy(textp[min(j, len(textp)) - 1])
                    set_text(np_, s)
                    if sp is not None:
                        anchor.addnext(sp); sp.addnext(np_)
                    else:
                        anchor.addnext(np_)
                    textp.append(np_)
            for extra in textp[len(new):]:
                prev = extra.getprevious()
                container.remove(extra)
                if prev is not None and prev.tag == q('p') and not ptext(prev).strip() and prev.getparent() is container:
                    container.remove(prev)


def remove_section(root, name):
    for p in [p for p in root.iter(q('p')) if heading_of(p) == name]:
        parent = p.getparent(); nodes = [p]
        for n in p.itersiblings():
            if n.tag == q('p') and heading_of(n):
                break
            nodes.append(n)
        for n in nodes:
            parent.remove(n)


def fill_table(root, rows, total):
    for tbl in root.iter(q('tbl')):
        trs = tbl.findall(q('tr'))
        if not trs or 'AREA' not in alltext(trs[0]):
            continue
        tot = [tr for tr in trs if 'TOTAL' in alltext(tr)][0]
        data = [tr for tr in trs[1:] if tr is not tot]
        proto = data[0]
        for tr in data:
            tbl.remove(tr)
        for row in rows:
            tr = copy.deepcopy(proto)
            for tc, val in zip(tr.findall(q('tc')), row):
                set_text(tc.find('.//' + q('p')), val)
            tot.addprevious(tr)
        if total:
            cells = tot.findall(q('tc'))
            for tc, val in zip(cells[1:], total):
                set_text(tc.find('.//' + q('p')), val)


def replace_exact(root, old, new):
    n = 0
    for p in root.iter(q('p')):
        if ptext(p).strip() == old.strip():
            set_text(p, new); n += 1
    if not n:
        raise ValueError('not found in exemplar: %r' % old)


def fit_photo(path, size_px, logo_png=None):
    im = ImageOps.exif_transpose(Image.open(path)).convert('RGB')
    im = ImageOps.fit(im, size_px, Image.LANCZOS, centering=(0.5, 0.5))
    if logo_png:
        # Mason Young watermark as on the exemplar: full logo, ~22.5% of the
        # photo width, centred, ~30% opacity
        logo = Image.open(io.BytesIO(logo_png)).convert('RGBA')
        w = int(im.width * 0.225)
        logo = logo.resize((w, int(logo.height * w / logo.width)), Image.LANCZOS)
        alpha = logo.getchannel('A').point(lambda a: int(a * 0.30))
        logo.putalpha(alpha)
        base = im.convert('RGBA')
        base.alpha_composite(logo, ((im.width - logo.width) // 2, (im.height - logo.height) // 2))
        im = base.convert('RGB')
    b = io.BytesIO(); im.save(b, 'JPEG', quality=88); return b.getvalue()


def main(src, spec_path, out):
    spec = json.load(open(spec_path))
    zin = zipfile.ZipFile(src)
    files = {n: zin.read(n) for n in zin.namelist()}
    root = etree.fromstring(files['word/document.xml'])
    base = json.load(open(re.sub(r'\.docx$', '.exemplar.json', src)))

    if spec.get('big_heading'):
        bh = spec['big_heading']
        for p in root.iter(q('p')):
            if ptext(p).strip() == base['big_heading']:
                set_text(p, bh['text'])
                for r in p.findall(q('r')):
                    for tag in ('sz', 'szCs'):
                        el = r.find(q('rPr') + '/' + q(tag))
                        if el is not None:
                            el.set(q('val'), str(bh['size']))
    for old, new in spec.get('rename_headings', {}).items():
        for p in root.iter(q('p')):
            t = ptext(p)
            if heading_of(p) == old:
                # keep the heading on one line: 2 fewer dots per extra letter
                # (TENURE/RENT has 100 dots, the FH template's TENURE/PRICE 98)
                m = re.match(r'^(\s*)' + re.escape(old) + r'(\s*)(\.+)(.*)$', t, re.S)
                dots = len(m.group(3)) - 2 * (len(new) - len(old))
                set_text(p, m.group(1) + new + m.group(2) + '.' * dots + m.group(4))
    for name in spec.get('remove_sections', []):
        remove_section(root, name)
    if spec.get('subtitle'):
        replace_exact(root, base['subtitle'], spec['subtitle'])
    if spec.get('address'):
        old = base['address']
        new = spec['address'] + [''] * (len(old) - len(spec['address']))
        for o, n in zip(old, new):
            replace_exact(root, o, n)
    if spec.get('sqft_line'):
        replace_exact(root, base['sqft_line'], spec['sqft_line'])
    for o, n in zip(base.get('bullets', []), spec.get('bullets', [])):
        replace_exact(root, o, n)
    if spec.get('sections'):
        fill_sections(root, spec['sections'])
    if spec.get('accommodation'):
        fill_table(root, spec['accommodation'], spec.get('total'))

    # photos: swap pixels only, cropped to each frame's own shape
    rels = etree.fromstring(files['word/_rels/document.xml.rels'])
    target = {r.get('Id'): 'word/' + r.get('Target') for r in rels}
    photos = spec.get('photos', {})
    wanted = {'hero': photos.get('hero')}
    for k, pth in enumerate(photos.get('gallery') or [], 1):
        wanted['g%d' % k] = pth
    for slot, rid in base.get('photo_slots', {}).items():
        path = wanted.get(slot)
        if path:
            w, h = base['frame_px'][slot]
            logo = files[base['logo_media']] if photos.get('watermark', True) else None
            files[target[rid]] = fit_photo(path, (w, h), logo)

    files['word/document.xml'] = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for n in zin.namelist():
            z.writestr(zin.getinfo(n), files[n])
    print('saved', out)


if __name__ == '__main__':
    main(*sys.argv[1:4])
