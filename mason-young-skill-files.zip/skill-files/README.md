# Mason Young skill files

Used by Claude's Mason Young skills (brochures, reports). Don't rename files without updating the skills.

- `brochures/LH.docx` – finished To Let brochure exemplar (Unit 7 Bickford Road) used as the base for every brochure
- `brochures/LH.exemplar.json` – which paragraphs/photo frames in that exemplar get replaced
- `brochures/fill_brochure.py` – fills the exemplar from a job spec
- `reports/Template Letter - *.doc` – the firm's appraisal letter templates
- `reports/Example - *.doc` – finished example letters
- `reports/fill_report.py` – fills a template from a job spec

Add new exemplars in the same folders (e.g. `brochures/FH.docx` for For Sale, `brochures/LFS.docx` for Lease For Sale).
